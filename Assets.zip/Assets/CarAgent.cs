using UnityEngine;
using Unity.MLAgents;
using Unity.MLAgents.Actuators;

public class CarAgent : Agent
{
    public CarController controller;
    public Transform checkpointsParent;
    private int currentCheckpoint;
    private Vector3 startPos;
    private Quaternion startRot;

    public override void Initialize()
    {
        startPos = transform.position;
        startRot = transform.rotation;
        currentCheckpoint = 0;
    }

    public override void OnActionReceived(ActionBuffers actions)
    {
        float steer = Mathf.Clamp(actions.ContinuousActions[0], -1f, 1f);
        float accel = Mathf.Clamp(actions.ContinuousActions[1], -1f, 1f);
        bool brake = actions.ContinuousActions[2] > 0.5f;

        controller.MoveCar(steer, accel, brake);
        AddReward(0.001f); // Survival bonus
    }

    public override void Heuristic(in ActionBuffers actionsOut)
    {
        var actions = actionsOut.ContinuousActions;
        
        // Steering (-1 to 1)
        actions[0] = 0f;
        if(Input.GetKey(KeyCode.A)) actions[0] = -1f;
        if(Input.GetKey(KeyCode.D)) actions[0] = 1f;
        
        // Acceleration/Brake (-1 to 1)
        actions[1] = 0f;
        if(Input.GetKey(KeyCode.W)) actions[1] = 1f;  // Full acceleration
        if(Input.GetKey(KeyCode.S)) actions[1] = -1f; // Full reverse
        
        // Separate brake key
        actions[2] = Input.GetKey(KeyCode.Space) ? 1f : 0f;
    }

    public override void OnEpisodeBegin()
    {
        transform.SetPositionAndRotation(startPos, startRot);
        controller.GetComponent<Rigidbody>().linearVelocity = Vector3.zero;
        currentCheckpoint = 0;
    }

    void OnTriggerEnter(Collider other)
    {
        if(other.CompareTag("Checkpoint"))
        {
            if(other.transform.GetSiblingIndex() == currentCheckpoint)
            {
                AddReward(1f);
                currentCheckpoint++;
                if(currentCheckpoint >= checkpointsParent.childCount)
                {
                    AddReward(5f);
                    EndEpisode();
                }
            }
        }
        else if(other.CompareTag("Wall"))
        {
            AddReward(-1f);
            EndEpisode();
        }
    }
}
