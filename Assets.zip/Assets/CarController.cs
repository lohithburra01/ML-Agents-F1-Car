using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class CarController : MonoBehaviour
{
    public float accelerationForce = 1500f;
    public float steeringForce = 35f;
    public float maxSpeed = 25f;
    public float brakeDrag = 5f;
    
    private Rigidbody rb;
    private float baseDrag = 0.5f;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        rb.linearDamping = baseDrag;
        rb.interpolation = RigidbodyInterpolation.Interpolate;
    }

    public void MoveCar(float steering, float acceleration, bool brake)
    {
        // Steering
        transform.Rotate(Vector3.up * steering * steeringForce * Time.fixedDeltaTime);
        
        // Acceleration
        if(rb.linearVelocity.magnitude < maxSpeed)
            rb.AddForce(transform.forward * acceleration * accelerationForce, ForceMode.Force);
        
        // Braking
        rb.linearDamping = brake ? brakeDrag : baseDrag;
    }
}
